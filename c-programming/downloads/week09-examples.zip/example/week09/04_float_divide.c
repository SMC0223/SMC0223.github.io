#include <stdio.h>

float divide(float a, float b);

int main(void) {
    float a = 7.0f;
    float b = 2.0f;
    float result = divide(a, b);
    printf("%.2f\n", result);
    return 0;
}

float divide(float a, float b) {
    return a / b;
}
