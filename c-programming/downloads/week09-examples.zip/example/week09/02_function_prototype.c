#include <stdio.h>

int add(int a, int b);

int main(void) {
    int sum = add(3, 4);
    printf("%d\n", sum);
    return 0;
}

int add(int a, int b) {
    return a + b;
}
