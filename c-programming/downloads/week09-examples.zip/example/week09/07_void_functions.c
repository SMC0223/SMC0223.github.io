#include <stdio.h>

int get_number(void) {
    return 10;
}

void show_grade(char value) {
    printf("%c\n", value);
}

int main(void) {
    int value = get_number();
    printf("%d\n", value);
    show_grade('B');
    return 0;
}
