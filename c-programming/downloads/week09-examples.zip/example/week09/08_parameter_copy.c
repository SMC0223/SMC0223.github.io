#include <stdio.h>

void increase(int count) {
    count = count + 1;
    printf("increase: %d\n", count);
}

int main(void) {
    int count = 3;
    increase(count);
    printf("main: %d\n", count);
    return 0;
}
