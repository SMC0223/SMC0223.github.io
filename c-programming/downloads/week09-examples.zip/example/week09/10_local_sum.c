#include <stdio.h>

void add_one(void) {
    int sum = 0;
    sum = sum + 1;
    printf("%d\n", sum);
}

int main(void) {
    add_one();
    add_one();
    return 0;
}
