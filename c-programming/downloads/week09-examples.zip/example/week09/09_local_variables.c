#include <stdio.h>

void show(void) {
    int x = 20;
    printf("show: %d, %p\n", x, (void *)&x);
}

int main(void) {
    int x = 10;
    printf("main: %d, %p\n", x, (void *)&x);
    show();
    return 0;
}
