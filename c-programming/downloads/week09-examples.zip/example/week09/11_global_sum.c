#include <stdio.h>

int sum = 0;

void add_one(void) {
    sum = sum + 1;
    printf("%d\n", sum);
}

int main(void) {
    add_one();
    add_one();
    return 0;
}
