#include <stdio.h>

int subtract(int a, int b) {
    return a - b;
}

int multiply(int a, int b, int c) {
    return a * b * c;
}

int main(void) {
    printf("difference = %d\n", subtract(7, 3));
    printf("product = %d\n", multiply(2, 3, 4));
    return 0;
}
