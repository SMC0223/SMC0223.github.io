#include <stdio.h>

float divide(int a, int b);

int main(void) {
    int a = 7;
    int b = 2;
    float result = divide(a, b);
    printf("%.2f\n", result);
    return 0;
}

float divide(int a, int b) {
    return (float)a / b;
}
