#include <stdio.h>
int main(void) {
    int A = 1, B = 0;
    while (조건식) {
        printf("%d,", A);

    }

    printf("\n");
    return 0;
}
