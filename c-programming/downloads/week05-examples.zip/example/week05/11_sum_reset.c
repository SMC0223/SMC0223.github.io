#include <stdio.h>
int main(void) {
    for (int i = 1; i <= 3; i++) {
        int sum = 0;
        sum += i;
        printf("%d ", sum);
    }
    printf("\n");
    return 0;
}
