#include <stdio.h>
int main(void) {
    for (int i = 3; i <= 1; i--) {
        printf("%d ", i);
    }
    printf("\n");
    return 0;
}
