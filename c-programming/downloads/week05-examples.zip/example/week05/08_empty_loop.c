#include <stdio.h>
int main(void) {
    int i = 0;
    for (i = 1; i <= 3; i++);
    {
        printf("%d ", i);
    }
    printf("\n");
    return 0;
}
