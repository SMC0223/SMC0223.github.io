#include <stdio.h>
int main(void) {
    int iter = 0;
    while (iter < 3) {
        printf("iter : %d\n", iter);
        iter++;
    }
    printf("== iter: %d\n", iter);
    return 0;
}
