#include <stdio.h>
int main(void) {
    int iter = 0;
    do {
        printf("iter: %d\n", iter);
        iter++;
    } while (iter < 3);
    printf("== iter: %d\n", iter);
    return 0;
}
