#include <stdio.h>
int main(void) {
    int n = 5;
    int row = 0, col = 0;
    int direction = 0;
    int top = 0, bottom = n - 1;
    int left = 0, right = n - 1;

    return 0;
}
