#include <stdio.h>
int main(void) {
    int start = 0;
    scanf("%d", &start);
    int current = start;

    return 0;
}
