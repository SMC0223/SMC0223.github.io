#include <stdio.h>
int main(void) {
    int sum = 0;
    for (int i = 1; i <= 3; i++) {
        sum = sum + i;
        printf("%d ", sum);
    }
    printf("\n");
    return 0;
}
