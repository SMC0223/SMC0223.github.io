#include <stdio.h>
int main(void) {
    for (int i = 1; i <= 5; i++) {
        if (i == 3) {
            continue;
        }
        printf("%d ", i);
    }
    printf("\n종료\n");
    return 0;
}
