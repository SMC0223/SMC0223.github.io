#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double randn(void);

int main(void) {
    srand(1);
    double alpha = 0.2;
    double x_filtered = 0.0;
    double dt = 0.001;
    for (double t = 0; t < 1; t = t + dt) {
        double noise = 0.1 * randn();
        double x = sin(2.0 * acos(-1.0) * t) + noise;

        x_filtered = (1-alpha)*x_filtered + alpha * x;
        printf("Time:%.3f Value: %.3f %.3f\n", t, x, x_filtered);
    }
    return 0;
}

double randn(void) {
    double u1 = (rand() + 1.0) / (RAND_MAX + 2.0);
    double u2 = (rand() + 1.0) / (RAND_MAX + 2.0);
    return sqrt(-2.0 * log(u1)) * cos(2.0 * acos(-1.0) * u2);
}
