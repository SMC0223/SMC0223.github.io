#include <stdio.h>
int main(void) {
    printf("0부터 4까지: ");
    for (int i = 0; i < 5; i++) {
        printf("%d ", i);
    }
    printf("\n1부터 5까지: ");
    for (int i = 1; i <= 5; i++) {
        printf("%d ", i);
    }
    printf("\n5부터 1까지: ");
    for (int i = 5; i >= 1; i--) {
        printf("%d ", i);
    }
    printf("\n2씩 증가: ");
    for (int i = 0; i <= 10; i += 2) {
        printf("%d ", i);
    }
    printf("\n30씩 증가: ");
    for (int angle = 0; angle <= 90; angle += 30) {
        printf("%d ", angle);
    }
    printf("\n");
    return 0;
}
