#include <stdio.h>
#include <math.h>
int main(void) {
    double pi = acos(-1.0), dt = 0.001;
    double fc = 5.0;
    double s = sin(pi * fc * dt);
    double alpha = 2*s*(sqrt(1+s*s)-s);
    double x_filtered = 0;
    for (double t = 0; t < 1; t = t + dt) {

        double x = sin(2*pi*t) + 0.3*sin(2*pi*50*t);
        x_filtered = (1-alpha)*x_filtered + alpha*x;
        printf("Time:%.3f Value: %.3f %.3f\n", t, x, x_filtered);
    }
    return 0;
}
