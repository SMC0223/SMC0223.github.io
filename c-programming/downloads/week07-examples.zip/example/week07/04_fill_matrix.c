#include <stdio.h>

int main(void) {
    int array[4][3] = {0};
    int value = 1;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 3; j++) array[i][j] = value++;
    }
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 3; j++) printf("%3d", array[i][j]);
        printf("\n");
    }
    return 0;
}
