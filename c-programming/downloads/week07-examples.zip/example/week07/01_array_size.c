#include <stdio.h>

int main(void) {
    char letters[5];
    int scores[5];
    printf("char size: %zu\n", sizeof(char));
    printf("int size: %zu\n", sizeof(int));
    printf("letters size: %zu\n", sizeof(letters));
    printf("scores size: %zu\n", sizeof(scores));
    return 0;
}
