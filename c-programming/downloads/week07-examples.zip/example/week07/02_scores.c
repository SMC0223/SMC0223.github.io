#include <stdio.h>

int main(void) {
    int scores[4] = {80, 95, 70, 85};
    printf("Before: %d %d %d %d\n", scores[0], scores[1], scores[2], scores[3]);
    scores[2] += 5;
    printf("After:  %d %d %d %d\n", scores[0], scores[1], scores[2], scores[3]);
    return 0;
}
