#include <stdio.h>

int main(void) {
    char letters[5] = {'A', 'B', 'C', 'D', 'E'};
    int scores[5] = {10, 20, 30, 40, 50};
    printf("char start: %p\n", (void *)letters);
    printf("char next:  %p %p\n", (void *)(letters + 1), (void *)&letters[1]);
    printf("int start:  %p\n", (void *)scores);
    printf("int next:   %p %p\n", (void *)(scores + 1), (void *)&scores[1]);
    return 0;
}
