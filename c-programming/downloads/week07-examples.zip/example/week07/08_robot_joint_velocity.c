// 컴파일: gcc -std=c99 08_robot_joint_velocity.c -lm
#include <math.h>
#include <stdio.h>

#define PI 3.141592653589793

int main(void) {
    const double dt = 0.02;
    const double L[2] = {1.0, 1.0};
    double theta[2] = {30 * PI / 180, 60 * PI / 180};
    double theta_dot[2] = {0.2, 0.1};
    double J[2][2], x_dot[2];

    for (int step = 0; step <= 250; step++) {
        double t = step * dt;
        J[0][0] = -L[0] * sin(theta[0]) - L[1] * sin(theta[0] + theta[1]);
        J[0][1] = -L[1] * sin(theta[0] + theta[1]);
        J[1][0] = L[0] * cos(theta[0]) + L[1] * cos(theta[0] + theta[1]);
        J[1][1] = L[1] * cos(theta[0] + theta[1]);
        for (int i = 0; i < 2; i++) {
            x_dot[i] = 0.0;
            for (int j = 0; j < 2; j++) x_dot[i] += J[i][j] * theta_dot[j];
        }
        printf("t=%.2f theta=(%.3f, %.3f) x_dot=(%.3f, %.3f)\n",
               t, theta[0], theta[1], x_dot[0], x_dot[1]);
        for (int i = 0; i < 2; i++) theta[i] += theta_dot[i] * dt;
    }
    return 0;
}
