// 컴파일: gcc -std=c99 09_robot_task_velocity.c -lm
#include <math.h>
#include <stdio.h>

#define PI 3.141592653589793

int main(void) {
    const double dt = 0.02;
    const double L[2] = {1.0, 1.0};
    double theta[2] = {0.0, 90 * PI / 180};
    double x_dot[2] = {0.2, 0.1};
    double J_inv[2][2], theta_dot[2];

    for (int step = 0; step <= 100; step++) {
        double t = step * dt;
        double d = L[0] * L[1] * sin(theta[1]);
        if (fabs(d) < 0.0001) {
            printf("Stopped: singular position\n");
            break;
        }
        J_inv[0][0] = L[1] * cos(theta[0] + theta[1]) / d;
        J_inv[0][1] = L[1] * sin(theta[0] + theta[1]) / d;
        J_inv[1][0] = -(L[0] * cos(theta[0]) + L[1] * cos(theta[0] + theta[1])) / d;
        J_inv[1][1] = -(L[0] * sin(theta[0]) + L[1] * sin(theta[0] + theta[1])) / d;
        for (int i = 0; i < 2; i++) {
            theta_dot[i] = 0.0;
            for (int j = 0; j < 2; j++) theta_dot[i] += J_inv[i][j] * x_dot[j];
        }
        if (fabs(theta_dot[0]) > 5 || fabs(theta_dot[1]) > 5) {
            printf("Stopped: joint velocity limit\n");
            break;
        }
        printf("t=%.2f theta=(%.3f, %.3f) theta_dot=(%.3f, %.3f)\n",
               t, theta[0], theta[1], theta_dot[0], theta_dot[1]);
        for (int i = 0; i < 2; i++) theta[i] += theta_dot[i] * dt;
    }
    return 0;
}
