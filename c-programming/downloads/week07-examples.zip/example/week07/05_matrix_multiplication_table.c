#include <stdio.h>

int main(void) {
    int array[3][3] = {0};
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) array[i][j] = (i + 1) * (j + 1);
    }
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) printf("%3d", array[i][j]);
        printf("\n");
    }
    return 0;
}
