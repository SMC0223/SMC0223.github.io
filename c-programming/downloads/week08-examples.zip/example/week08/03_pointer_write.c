#include <stdio.h>

int main(void) {
    int value = 10;
    int *p = &value;
    printf("value = %d, *p = %d\n", value, *p);
    *p = 30;
    printf("value = %d, *p = %d\n", value, *p);
    return 0;
}
