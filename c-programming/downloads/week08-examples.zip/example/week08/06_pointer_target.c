#include <stdio.h>

int main(void) {
    int value = 10;
    int other = 30;
    int *p = &value;
    p = &other;
    *p = 50;
    printf("value = %d, other = %d\n", value, other);
    return 0;
}
