#include <stdio.h>

int main(void) {
    int value = 10;
    int *p = NULL;

    if (p == NULL) {
        printf("Assign an address first.\n");
    }
    p = &value;
    if (p != NULL) {
        printf("*p = %d\n", *p);
    }
    return 0;
}
