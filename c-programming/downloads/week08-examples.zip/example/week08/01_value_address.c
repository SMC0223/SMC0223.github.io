#include <stdio.h>

int main(void) {
    int value = 10;
    printf("value = %d, address = %p\n", value, (void *)&value);
    value = 20;
    printf("value = %d, address = %p\n", value, (void *)&value);
    return 0;
}
