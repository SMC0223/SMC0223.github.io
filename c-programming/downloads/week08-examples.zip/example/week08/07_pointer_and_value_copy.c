#include <stdio.h>

int main(void) {
    int value = 10;
    int copy = value;
    int *p = &value;
    int *q = p;

    *q += 5;
    printf("value = %d, copy = %d, *p = %d, *q = %d\n",
           value, copy, *p, *q);
    return 0;
}
