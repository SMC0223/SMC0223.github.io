#include <stdio.h>

int main(void) {
    int a = 5;
    printf("a = %d\n", a);
    int *b = &a;
    *b = 10;
    printf("a = %d\n", a);
    int **c = &b;
    **c = 15;
    printf("a = %d, *b = %d, **c = %d\n", a, *b, **c);
    return 0;
}
