#include <stdio.h>

int main(void) {
    int value = 10;
    int *p;
    p = &value;

    printf("value = %d, *p = %d\n", value, *p);
    printf("&value = %p\n", (void *)&value);
    printf("p      = %p\n", (void *)p);
    printf("&p     = %p\n", (void *)&p);
    return 0;
}
