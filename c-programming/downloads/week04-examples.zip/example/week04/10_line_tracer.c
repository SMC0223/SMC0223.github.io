#include <stdio.h>
int main(void) {
    int left = 0, right = 0;
    int left_speed = 0, right_speed = 0;
    scanf("%d %d", &left, &right);

    printf("%d %d\n", left_speed, right_speed);
    return 0;
}
