#include <stdio.h>
int main(void) {
    double value1 = 0.0, value2 = 0.0;
    double result = 0.0;
    char op = ' ';
    scanf("%lf %c %lf", &value1, &op, &value2);

    printf("%.2f %c %.2f = %.2f\n",
           value1, op, value2, result);
    return 0;
}
