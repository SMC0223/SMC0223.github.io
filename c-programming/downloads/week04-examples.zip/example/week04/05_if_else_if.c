#include <stdio.h>
int main(void) {
    int x = 5;
    if (x > 0) {
        x = x - 5;
    }
    if (x == 0) {
        printf("ZERO\n");
    } else {
        printf("NONZERO\n");
    }
    return 0;
}
