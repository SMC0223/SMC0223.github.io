#include <stdio.h>
int main(void) {
    int stop = 0, battery = 0;
    scanf("%d %d", &stop, &battery);

    return 0;
}
