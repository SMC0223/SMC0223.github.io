#include <stdio.h>
int main(void) {
    double weight_kg = 0.0, height_cm = 0.0;
    scanf("%lf %lf", &weight_kg, &height_cm);
    double height_m = height_cm / 100.0;
    double bmi_value = weight_kg / (height_m * height_m);
    printf("당신은 ");
    if (조건문) {

    } else {

    }
    printf("입니다\n");
    return 0;
}
