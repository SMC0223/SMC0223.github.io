#include <stdio.h>
int main(void) {
    int total = 0, fee = 0;
    scanf("%d", &total);
    if (total >= 10000) {
        fee = 0;
    } else {
        fee = 3000;
    }
    printf("fee=%d\n", fee);
    printf("payment=%d\n", total + fee);
    return 0;
}
