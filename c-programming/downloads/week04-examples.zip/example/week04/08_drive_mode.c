#include <stdio.h>
int main(void) {
    int mode = 0;
    scanf("%d", &mode);
    switch (mode) {
        case 1: printf("MANUAL\n"); break;
        case 2: printf("AUTO\n"); break;
        default: printf("UNKNOWN\n"); break;
    }
    printf("END\n");
    return 0;
}
