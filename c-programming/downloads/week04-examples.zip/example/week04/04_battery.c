#include <stdio.h>
int main(void) {
    int battery = 0;
    scanf("%d", &battery);

    return 0;
}
