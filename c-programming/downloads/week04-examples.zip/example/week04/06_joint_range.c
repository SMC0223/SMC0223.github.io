#include <stdio.h>
int main(void) {
    double angle = 0.0;
    scanf("%lf", &angle);

    return 0;
}
