#include <stdio.h>
int main(void) {
    double value1 = 0.0, value2 = 0.0;
    scanf("%lf %lf", &value1, &value2);
    //  이 부분을 채우시오
    return 0;
}
