#include <stdio.h>
int main(void) {
    double signal = 0.00001234;
    printf("fixed: %.8f\n", signal);
    printf("exponent: %.3e\n", signal);
    printf("significant: %.4g\n", signal);
    signal = 1234567.0;
    printf("large: %.4g\n", signal);
    return 0;
}
