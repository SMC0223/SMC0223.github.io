#include <stdio.h>
int main(void) {
    double value = 12.345;
    printf("|%10.2f|\n", value);
    printf("|%-10.2f|\n", value);
    printf("|%-10s|\n", "Joint 1");
    printf("|%4d|\n", 123456);
    return 0;
}
