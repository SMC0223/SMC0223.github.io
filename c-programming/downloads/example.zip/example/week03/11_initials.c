#include <stdio.h>
int main(void) {
    char initial_1,initial_2,initial_3;
    // scanf를 사용하여 작성하시오.
    // printf를 사용하여 작성하시오.
    return 0;
}
