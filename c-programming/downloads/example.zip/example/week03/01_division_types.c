#include <stdio.h>
int main(void) {
    int a = 7, b = 2;
    printf("int / int    : %d\n", a / b);
    printf("int / float  : %.1f\n", a / 2.0f);
    printf("int / double : %.1f\n", a / 2.0);
    printf("cast before  : %.1f\n", (double)a / b);
    printf("cast after   : %.1f\n", (double)(a / b));
    return 0;
}
