#include <stdio.h>
int main(void) {
    double q1 = 30.0, q2 = 60.0;
    printf("%-10s %12s\n", "Joint", "Position(deg)");
    printf("%-10s %12.2f\n", "Joint 1", q1);
    printf("%-10s %12.2f\n", "Joint 2", q2);
    return 0;
}
