# WEEK 03 예제 프로그램

현재 `content/week03.md`의 C 실습과 동일한 코드. 실습 파일마다 `main`이 있으므로 한 파일씩 빌드·실행.

## GCC 실행

```powershell
gcc -std=c11 -Wall -Wextra 08_calculator_sum.c -o calculator.exe
.\calculator.exe
```

실행 후 `10 20` 입력. 입력이 필요한 파일에는 같은 이름의 `.txt` 입력 예시 제공.

```powershell
Get-Content .\08_calculator_sum.txt | .\calculator.exe
```

진자 운동은 수학 라이브러리 연결 필요:

```powershell
gcc -std=c11 -Wall -Wextra 13_pendulum.c -o pendulum.exe -lm
.\pendulum.exe
```

Visual Studio Developer PowerShell 예시:

```powershell
cl /nologo /utf-8 /std:c11 /W4 08_calculator_sum.c /Fe:calculator.exe
.\calculator.exe
```

## 실습 목록

| 번호 | 파일 | 내용 | 입력 예시 | 구성 |
| --- | --- | --- | --- | --- |
| 1 | [01_division_types.c](01_division_types.c) | 나눗셈의 자료형과 형 변환 비교 | 없음 | 실행 예제 |
| 2 | [02_print_types.c](02_print_types.c) | 여러 자료형 출력 | 없음 | 실행 예제 |
| 3 | [03_float_precision.c](03_float_precision.c) | 실수 출력 정밀도 | 없음 | 실행 예제 |
| 4 | [04_width_alignment.c](04_width_alignment.c) | 출력 폭과 정렬 | 없음 | 실행 예제 |
| 5 | [05_joint_table.c](05_joint_table.c) | 관절 상태 표 출력 | 없음 | 실행 예제 |
| 6 | [06_scientific_notation.c](06_scientific_notation.c) | 센서값의 소수·지수·유효숫자 출력 | 없음 | 실행 예제 |
| 7 | [07_motor_format.c](07_motor_format.c) | 모터 번호와 관절각 표시 형식 | 없음 | 실행 예제 |
| 8 | [08_calculator_sum.c](08_calculator_sum.c) | 계산기를 만들어보자 1 | `10 20` | 실행 예제 |
| 9 | [09_calculator_arithmetic.c](09_calculator_arithmetic.c) | 계산기를 만들어보자 2 | `10.5 2.0` | 학생 완성용 시작 코드 |
| 10 | [10_force_motion.c](10_force_motion.c) | F=ma | 없음 | 실행 예제 |
| 11 | [11_initials.c](11_initials.c) | 이니셜 입력하기 | `S M C` | 학생 완성용 시작 코드 |
| 12 | [12_hex_binary.c](12_hex_binary.c) | 16진수를 입력하여 10진수·2진수로 출력 | `2A` | 실행 예제 |
| 13 | [13_pendulum.c](13_pendulum.c) | 진자 운동 | `0` | 학생 완성용 시작 코드 |

## 학생 완성 영역

- 09번: 두 실수의 합·차·곱·몫 출력 코드 작성. 두 번째 입력은 0이 아닌 값 사용.
- 11번: 이니셜 3개를 `scanf`로 입력받아 `printf`로 출력. 작성 전 미사용 변수 경고 발생 가능.
- 13번: 초기 각도 입력 및 반복문 안의 각위치·각속도·각가속도 출력 작성. 시작 코드는 출력 헤더만 표시.
- 13번의 q=0은 오른쪽(+x), 양의 각도는 반시계 방향. 각도 입력은 deg, 내부 계산은 rad. 기본 초기값 0도에서 중력으로 낙하.
- 입력 예시 파일은 입력을 작성한 코드에서 활용. 제공 코드에 없는 입력·출력 문장을 임의로 추가하지 않음.
- 조건문 학습 전이므로 올바른 형식·범위의 입력을 전제로 실습.

`python scripts/sync-week03-examples.py`로 강의 원고에서 재생성. 저장소의 `example/week03`과 작업 폴더의 `../example/week03`에 같은 파일 생성.
