#include <stdio.h>
int main(void) {
    double F = 1; // 단위 N
    double m = 1; // 단위 kg
    //scanf를 사용하여 F,m값을 수정하시오
    double dt = 0.001; 
    double a=0;  // 가속도
    double v= 0; // 속도
    double x = 0; //위치
    double time = 0; // 시뮬레이션 시간
    for (time = 0.0; time < 1.0;) {
      a = F / m; // Forward Dynamics
      v= v+a*dt; // Euler step
      x = x+v*dt; // Euler step
      time+=dt;
      //printf("x : \t  \n",); printf를 사용해서 수정하시오.
    }
    return 0;
}
