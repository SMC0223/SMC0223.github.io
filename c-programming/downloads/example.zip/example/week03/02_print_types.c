#include <stdio.h>
int main(void) {
    int count = 3;
    unsigned int mask = 255u;
    double position = 1.25;
    char joint = 'A';
    printf("count=%d, mask=%u\n", count, mask);
    printf("position=%.2f m\n", position);
    printf("joint=%c, name=%s\n", joint, "Robot");
    printf("hex=%x\n", mask);
    return 0;
}
