#include <stdio.h>
int main(void) {
    unsigned int value = 0;
    scanf("%x", &value);
    printf("hex=%02X\n", value);
    printf("decimal=%u\n", value);
    printf("binary=%u%u%u%u%u%u%u%u\n",
           (value >> 7) & 1u, (value >> 6) & 1u,
           (value >> 5) & 1u, (value >> 4) & 1u,
           (value >> 3) & 1u, (value >> 2) & 1u,
           (value >> 1) & 1u, value & 1u);
    return 0;
}
