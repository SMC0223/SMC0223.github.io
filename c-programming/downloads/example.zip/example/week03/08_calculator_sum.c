#include <stdio.h>
int main(void) {
    int value1 = 0, value2 = 0;
    scanf("%d %d", &value1, &value2);
    printf("result=%d\n", value1 + value2);
    return 0;
}
