#include <stdio.h>
int main(void) {
    int motor = 7;
    double target = 30.0, error = -0.125;
    unsigned int battery = 80u;
    printf("Motor %04d\n", motor);
    printf("target: |%+9.2f| deg\n", target);
    printf("error : |%+9.3f| deg\n", error);
    printf("battery: %u%%\n", battery);
    return 0;
}
