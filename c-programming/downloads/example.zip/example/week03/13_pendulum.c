#include <stdio.h>
#include <math.h>
#define D2R  3.141592653589793/180.0;  //deg to radian
double ForwardDynamics(double q)
{
    double m = 1.0, L = 1.0, g = 9.81;
    double Lc = L / 2.0;
    double I = m * L * L / 3.0;
    return -m * g * Lc * cos(q) / I;
}
int main(void)
{   
    double initial_deg = 0.0;
    //scanf("%lf"); 활용하여 초기값 변경.
    double dt = 0.001; //sampling time
    double q = initial_deg * D2R;
    double dq = 0.0;
    double ddq = ForwardDynamics(q);
    double time = 0.0;

    printf("time(s) q(rad) dq(rad/s) ddq(rad/s^2)\n");
    // 강사 제공: 속도와 각도를 0.001초 간격으로 갱신
    for (time = 0.0; time < 1.0; time += dt) {
        dq = dq + ddq * dt; //Euler step
        q = q + dq * dt; // Euler step
        ddq = ForwardDynamics(q);
        // printf, \n 를 활용하여 q, dq, dqq를 출력하라
    }
    return 0;
}
