#include <stdio.h>
int main(void) {
    double value = 3.141592653589793;
    printf("default: %f\n", value);
    printf("2 digits: %.2f\n", value);
    printf("4 digits: %.4f\n", value);
    printf("stored: %.15f\n", value);
    return 0;
}
