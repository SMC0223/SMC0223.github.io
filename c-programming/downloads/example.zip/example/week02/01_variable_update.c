/* 실습 1: 변수 변경 전과 후 출력하기 */
#include <stdio.h>

int main(void)
{
    unsigned short room101 = 2;
    unsigned int room102 = 3;
    printf("room101: %hu\n", room101);
    printf("room102: %u\n", room102);

    room102 = room101;
    room101 = 5;
    
    printf("room101: %hu\n", room101);
    printf("room102: %u\n", room102);


    return 0;
}
