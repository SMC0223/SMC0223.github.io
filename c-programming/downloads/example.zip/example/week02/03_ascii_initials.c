/* 실습 3: ASCII 숫자 코드로 자신의 이니셜 출력하기 */
#include <stdio.h>
int main(void) {
    char initial1 = 0;  // 자신의 첫번째 initial 숫자 S = 83
    char initial2 = 0;  //  자신의 두번째 initial 숫자 M = 77
    char initial3 = 0;  //  자신의 세번째 initial 숫자 C = 67

    printf("%c%c%c\n", initial1, initial2, initial3);
    return 0;
}
