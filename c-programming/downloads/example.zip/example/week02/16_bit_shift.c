/* 실습 16: 비트 이동과 2로 나누기 — 클릭형 화면에 대응하는 C 예제 */
#include <stdio.h>

int main(void) {
    unsigned int a = 13u;
    unsigned int n = 1u;  // 8비트 실습에서는 0~7 사용
    printf("left (8 bits): %u\n", (a << n) & 255u);
    printf("right: %u\n", a >> n);
    printf("divide by 2: %u\n", a / 2u);
    printf("right 2: %u\n", a >> 2);
    printf("right 3: %u\n", a >> 3);
    printf("right 4: %u\n", a >> 4);
    return 0;
}
