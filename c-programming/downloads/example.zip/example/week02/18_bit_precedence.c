/* 실습 18: a & b == 0의 묶임 확인 */
#include <stdio.h>
int main(void) {
    unsigned char a = 2u; // 0000 0010
    unsigned char b = 1u; // 0000 0001

    printf("a & b == 0  : %d\n", a & b == 0);
    printf("a & (b == 0): %d\n", a & (b == 0));
    printf("(a & b) == 0: %d\n", (a & b) == 0);
    return 0;
}
