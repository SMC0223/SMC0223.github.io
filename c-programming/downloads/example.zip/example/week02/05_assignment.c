/* 실습 5: 대입 연산자 =로 값 저장 */
#include <stdio.h>
int main(void) {
    int count = 2;
    printf("expression: %d\n", count + 1);
    printf("before: %d\n", count);
    count = count + 1;
    printf("after: %d\n", count);
    return 0;
}
