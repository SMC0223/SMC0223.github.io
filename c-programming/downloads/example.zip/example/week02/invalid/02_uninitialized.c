/* 실습 2: 빈 방을 출력하면? */
/* 초기화 전 읽기: 출력 결과 보장 불가. 경고 확인용이며 실행 대상에서 제외함. */
#include <stdio.h>

int main(void)
{
    unsigned short room101;  // 변수 선언
    // 초기화되지 않은 변수 사용: 잘못된 예
    printf("room101 = %hu\n", room101);

    return 0;
}
