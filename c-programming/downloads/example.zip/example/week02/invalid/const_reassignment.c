#include <stdio.h>

int main(void) {
    const unsigned short room101 = 10;
    room101 = 20;  // 컴파일 오류 확인용
    printf("%hu\n", room101);
    return 0;
}
