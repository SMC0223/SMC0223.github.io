# WEEK 02 예제 프로그램

현재 `c-programming-course/content/week02.md` 기준. 파일 하나마다 독립적인 프로그램이며, 한 번에 한 파일만 빌드함.

## 실행 방법

GCC 예시 (이 폴더에서 실행):

```powershell
gcc -std=c11 -Wall -Wextra 01_variable_update.c -o demo.exe
.\demo.exe
```

Visual Studio Developer PowerShell 예시:

```powershell
cl /nologo /utf-8 /std:c11 /W4 01_variable_update.c /Fe:demo.exe
.\demo.exe
```

한글 출력은 UTF-8 터미널 사용. 각 파일에 main이 있으므로 모든 파일을 하나의 실행 파일로 연결하지 않음.

## 강의 실습

| 번호 | 파일 | 내용 |
| --- | --- | --- |
| 1 | [01_variable_update.c](01_variable_update.c) | 실습 1: 변수 변경 전과 후 출력하기 |
| 2 | [invalid/02_uninitialized.c](invalid/02_uninitialized.c) | 실습 2: 빈 방을 출력하면? |
| 3 | [03_ascii_initials.c](03_ascii_initials.c) | 실습 3: ASCII 숫자 코드로 자신의 이니셜 출력하기 |
| 4 | [04_const_room.c](04_const_room.c) | 실습 4: 봉인된(const) 객실(자료형)의 손님(값)을 바꿀 수 있을까? |
| 5 | [05_assignment.c](05_assignment.c) | 실습 5: 대입 연산자 =로 값 저장 |
| 6 | [06_arithmetic.c](06_arithmetic.c) | 실습 6: 산술 연산으로 주문 금액 계산 |
| 7 | [07_division_remainder.c](07_division_remainder.c) | 실습 7: 나눗셈과 나머지로 쿠키 나누기 |
| 8 | [08_compound_assignment.c](08_compound_assignment.c) | 실습 8: 복합 대입으로 포인트 적립과 사용 |
| 9 | [09_increment_decrement.c](09_increment_decrement.c) | 실습 9: 증감 연산자로 대기 인원 변경 |
| 10 | [10_prefix_postfix.c](10_prefix_postfix.c) | 실습 10: 전위와 후위의 결과 비교 |
| 11 | [11_comparison.c](11_comparison.c) | 실습 11: 관계 연산으로 무료 배송 기준 비교 |
| 12 | [12_logical.c](12_logical.c) | 실습 12: 논리 연산으로 할인 조건 조합 |
| 13 | [13_conditional.c](13_conditional.c) | 실습 13: 조건 연산자 ? :로 배송비 선택 |
| 14 | [14_bitwise.c](14_bitwise.c) | 실습 14: AND·OR·XOR로 같은 자리끼리 비교 |
| 15 | [15_bitwise_not.c](15_bitwise_not.c) | 실습 15: NOT으로 모든 비트 반전 |
| 16 | [16_bit_shift.c](16_bit_shift.c) | 실습 16: 비트 이동 <<와 >>로 자리 옮기기 |
| 17 | [17_precedence.c](17_precedence.c) | 실습 17: 괄호와 우선순위로 계산 순서 확인 |
| 18 | [18_bit_precedence.c](18_bit_precedence.c) | 실습 18: a & b == 0의 묶임 확인 |
| 19 | [19_robot_arm.c](19_robot_arm.c) | 종합 실습 19: 2자유도 로봇 팔의 x, y 계산 |

- 02번은 초기화 전 읽기의 잘못된 예. 출력 결과 보장 불가, 정상 실행 대상에서 제외함.
- 03번은 학생용 시작 코드. 숫자 0 세 개를 자신의 ASCII 이니셜 코드로 수정함. SMC 예시 답안은 concepts/ascii_initials_answer.c 참고.
- 04번은 정상 실행 가능. 주석을 해제하면 const 변경 오류 확인 가능.
- 14~16번은 강의의 클릭형 실습을 C 코드로 옮긴 예제. NOT과 왼쪽 이동은 하위 8비트 표시.
- 18번은 괄호 누락 경고가 의도적으로 발생함. 출력은 0, 0, 1.
- 19번은 길이 1.0 m, 0.8 m와 각도 30°, 60°를 사용함. 결과는 x=0.87 m, y=1.30 m. θ2는 첫 번째 팔 기준의 상대 각도.

로봇 예제의 GCC 빌드: 수학 라이브러리 연결을 위해 `-lm`을 소스 뒤에 지정함.

```powershell
gcc -std=c11 -Wall -Wextra 19_robot_arm.c -o robot.exe -lm
.\robot.exe
```

강의 순서: 로봇 그림·수식 설명 → 19번 C 실습 → 클릭형 로봇 시각화. C 코드의 길이·각도를 시각화에도 동일하게 입력하여 비교함.

14~16번은 클릭형 실습에서 확인하는 값을 C로 계산하는 보충 예제. 웹 화면의 초기 입력 0과 달리 5·3·13 등 비교할 값을 미리 지정함.

## 개념 보충 예제

- [hotel_variables.c](concepts/hotel_variables.c)
- [declaration_initialization.c](concepts/declaration_initialization.c)
- [copy_value.c](concepts/copy_value.c)
- [bool_light.c](concepts/bool_light.c)
- [short_circuit.c](concepts/short_circuit.c)
- [ascii_initials_answer.c](concepts/ascii_initials_answer.c)
- [unsigned_wrap.c](concepts/unsigned_wrap.c)
- [float_precision.c](concepts/float_precision.c)

## 오류 확인 전용

- [02_uninitialized.c](invalid/02_uninitialized.c): 초기화하지 않은 지역 변수 읽기. 컴파일 경고 확인용이며 실행 결과를 정답으로 사용하지 않음.
- [const_reassignment.c](invalid/const_reassignment.c): const 변경으로 컴파일 실패하는 예.
