/* 실습 10: 전위와 후위의 결과 비교 */
#include <stdio.h>
int main(void) {
    int a = 3;
    int b = 3;
    int first = ++a;
    int second = b++;
    printf("a: %d, first: %d\n", a, first);
    printf("b: %d, second: %d\n", b, second);
    return 0;
}
