/* 실습 6: 산술 연산으로 주문 금액 계산 */
#include <stdio.h>
int main(void) {
    const int PRICE = 4000;
    int count = 2;
    int fee = 500;
    int discount = 1000;
    int total = PRICE * count + fee - discount;
    printf("total: %d\n", total);
    return 0;
}
