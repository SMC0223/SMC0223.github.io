/* 실습 13: 조건 연산자 ? :로 배송비 선택 */
#include <stdio.h>
int main(void) {
    int total = 9000;
    int fee = (total >= 10000) ? 0 : 3000;
    printf("fee: %d\n", fee);
    printf("payment: %d\n", total + fee);
    return 0;
}
