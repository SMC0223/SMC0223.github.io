/* 실습 4: 봉인된(const) 객실(자료형)의 손님(값)을 바꿀 수 있을까? */
#include <stdio.h>
int main(void) {
    const unsigned short room101 = 10;
    // room101 = 20;
    printf("room101: %hu\n", room101);
    return 0;
}
