/* 실습 17: 괄호와 우선순위로 계산 순서 확인 */
#include <stdio.h>
int main(void) {
    int price = 4000, fee = 500, count = 2;
    printf("once: %d\n", price * count + fee);
    printf("each: %d\n", (price + fee) * count);
    return 0;
}
