/* 실습 14: AND·OR·XOR — 클릭형 화면에 대응하는 C 예제 */
#include <stdio.h>

int main(void) {
    unsigned int a = 5u, b = 3u;
    printf("AND: %u\n", a & b);
    printf("OR: %u\n", a | b);
    printf("XOR: %u\n", a ^ b);
    return 0;
}
