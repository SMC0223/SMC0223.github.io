/* 종합 실습 19: 2자유도 로봇 팔의 x, y 계산 */
#include <stdio.h>
#include <math.h>
int main(void) {
    const double PI = 3.141592653589793;
    const double L1 = 1.0, L2 = 0.8;
    double angle1 = 30.0, angle2 = 60.0;
    double t1 = angle1 * PI / 180.0;
    double t2 = angle2 * PI / 180.0;
    double x = L1 * cos(t1) + L2 * cos(t1 + t2);
    double y = L1 * sin(t1) + L2 * sin(t1 + t2);
    printf("x = %.2f m\n", x);
    printf("y = %.2f m\n", y);
    return 0;
}
