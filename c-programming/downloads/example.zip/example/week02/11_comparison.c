/* 실습 11: 관계 연산으로 무료 배송 기준 비교 */
#include <stdio.h>
int main(void) {
    int total = 9000;
    const int LIMIT = 10000;
    printf("<  : %d\n", total < LIMIT);
    printf("<= : %d\n", total <= LIMIT);
    printf(">  : %d\n", total > LIMIT);
    printf(">= : %d\n", total >= LIMIT);
    printf("== : %d\n", total == LIMIT);
    printf("!= : %d\n", total != LIMIT);
    return 0;
}
