/* 실습 12: 논리 연산으로 할인 조건 조합 */
#include <stdio.h>
int main(void) {
    int member = 1;
    int coupon = 0;
    printf("both: %d\n", member && coupon);
    printf("either: %d\n", member || coupon);
    printf("not member: %d\n", !member);
    return 0;
}
