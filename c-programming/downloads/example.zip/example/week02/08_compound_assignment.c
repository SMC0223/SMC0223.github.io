/* 실습 8: 복합 대입으로 포인트 적립과 사용 */
#include <stdio.h>
int main(void) {
    int points = 1000;
    points += 500;
    printf("add: %d\n", points);
    points -= 300;
    printf("use: %d\n", points);
    points *= 2;
    printf("double: %d\n", points);
    points /= 3;
    printf("divide: %d\n", points);
    points %= 100;
    printf("remainder: %d\n", points);
    return 0;
}
