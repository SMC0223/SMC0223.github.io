#include <stdio.h>

int main(void) {
    unsigned short room101 = 10;
    unsigned int room102 = room101;
    room101 = 20;
    printf("room101: %hu\n", room101);
    printf("room102: %u\n", room102);
    return 0;
}
