#include <stdio.h>
int main(void) {
    unsigned char count = 255;
    printf("변경 전: %d\n", count);
    count = count + 1;
    printf("변경 후: %d\n", count);
    return 0;
}
