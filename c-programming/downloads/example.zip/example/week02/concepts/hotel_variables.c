#include <stdio.h>

int main(void) {
    unsigned short room101 = 2;
    unsigned int room102 = 65536u;
    unsigned char room201 = 255;
    printf("room101: %hu\n", room101);
    printf("room102: %u\n", room102);
    printf("room201: %hhu\n", room201);
    return 0;
}
