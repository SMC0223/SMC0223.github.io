#include <stdio.h>

int main(void) {
    int age = 25;
    int student_age = (18 <= age) && (age <= 24);
    int people = 0;
    int enough = (people != 0) && (10 / people >= 2);
    printf("student age: %d\n", student_age);
    printf("enough: %d\n", enough);
    return 0;
}
