#include <stdio.h>

int main(void) {
    unsigned short room101;  // 선언 후 읽기 전에 값 저장
    room101 = 2;
    printf("initial: %hu\n", room101);
    room101 = 5;
    printf("updated: %hu\n", room101);
    return 0;
}
