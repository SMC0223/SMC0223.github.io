#include <stdio.h>

int main(void) {
    char initial1 = 83, initial2 = 77, initial3 = 67;
    printf("%c%c%c\n", initial1, initial2, initial3);
    return 0;
}
