#include <stdio.h>

int main(void) {
    float pi_f = 3.14159265358979323846f; // float 상수는 숫자 다음에 f를 붙임.
    double pi_d = 3.14159265358979323846;
    printf("float : %.15f\n", pi_f); // float형 값을 소수점 15자리까지 표시
    printf("double: %.15f\n", pi_d); // double형 값을 소수점 15자리까지 표시
    
    return 0;
}
