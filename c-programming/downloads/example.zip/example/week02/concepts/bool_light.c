#include <stdbool.h>
#include <stdio.h>

int main(void) {
    bool isOn = 0;
    printf("off: %d\n", isOn);
    isOn = 1;
    printf("on: %d\n", isOn);
    isOn = 5;
    printf("nonzero: %d\n", isOn);
    return 0;
}
