/* 실습 15: NOT의 하위 8비트 — 클릭형 화면에 대응하는 C 예제 */
#include <stdio.h>

int main(void) {
    unsigned int a = 5u;
    /* unsigned int 전체 반전 후 하위 8비트만 표시함. */
    printf("A: %u\n", a);
    printf("NOT (8 bits): %u\n", (~a) & 255u);
    return 0;
}
