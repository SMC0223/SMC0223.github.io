/* 실습 9: 증감 연산자로 대기 인원 변경 */
#include <stdio.h>
int main(void) {
    int waiting = 3;
    printf("start: %d\n", waiting);
    waiting++;
    printf("arrival: %d\n", waiting);
    waiting--;
    printf("entry: %d\n", waiting);
    return 0;
}
