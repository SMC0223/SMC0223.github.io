/* 실습 7: 나눗셈과 나머지로 쿠키 나누기 */
#include <stdio.h>
int main(void) {
    int cookies = 7;
    int people = 2;
    printf("each: %d\n", cookies / people);
    printf("left: %d\n", cookies % people);
    printf("average: %.1f\n", (double)cookies / people);
    return 0;
}
