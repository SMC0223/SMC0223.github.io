#include <stdio.h>
#include <windows.h> // 윈도우 콘솔 설정을 위한 헤더 파일 추가

int main(void)
{
    // 콘솔 출력 인코딩을 UTF-8로 설정하여 한글 깨짐 방지
    SetConsoleOutputCP(CP_UTF8);
    printf("Hello, 성민창!\n");
    return 0;
}