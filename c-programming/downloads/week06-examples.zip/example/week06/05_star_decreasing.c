// 입력: 양의 홀수 n.
#include <stdio.h>

int main(void) {
    int n = 0;
    scanf("%d", &n);
    for (int i = n; i >= 1; i -= 2) {
        for (int j = 1; j <= i; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
