#include <stdio.h>

int main(void) {
    int a[5] = {5, 3, 4, 1, 2};
    for (int k = 0; k < 5; k++) printf("%d ", a[k]);
    printf("\n");

    for (int i = 0; i < 4; i++) {
        int min = i;
        for (int j = i + 1; j < 5; j++) {
            if (a[j] < a[min]) min = j;
        }
        int temp = a[i];
        a[i] = a[min];
        a[min] = temp;
        for (int k = 0; k < 5; k++) printf("%d ", a[k]);
        printf("\n");
    }
    return 0;
}
