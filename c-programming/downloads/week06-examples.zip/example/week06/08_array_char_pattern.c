/* Source: 2011 CSAT, Vocational Education, Programming, Question 10.
   Entry point adapted to standard C; loop and output logic preserved. */
#include <stdio.h>

int main(void) {
    char Sh[] = {'#', '@', '&'};
    int a, b;
    for (a = 1; a <= 3; a++) {
        for (b = 1; b <= a; b++) {
            printf("%c", Sh[a-b]);
        }
        printf("\n");
    }
    return 0;
}
