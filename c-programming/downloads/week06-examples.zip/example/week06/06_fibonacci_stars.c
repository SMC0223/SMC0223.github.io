// 입력: 출력할 줄 수 n (1~10).
#include <stdio.h>

int main(void) {
    int n;
    int A = 1, B = 0;
    if (scanf("%d", &n) != 1 || n < 1 || n > 10) return 1;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < A; j++) printf("*");
        printf("\n");
        A = A + B;
        B = A - B;
    }
    return 0;
}
