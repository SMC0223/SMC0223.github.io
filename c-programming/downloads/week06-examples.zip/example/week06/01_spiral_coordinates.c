#include <stdio.h>

int main(void) {
    int n = 5;
    int row = 0, col = 0, direction = 0;
    int top = 0, bottom = n - 1;
    int left = 0, right = n - 1;

    for (int count = 1; count <= n * n; count++) {
        printf("%d %d\n", row, col);
        if (count == n * n) break;
        if (direction == 0 && col == right) {
            top++;
            direction = 1;
        } else if (direction == 1 && row == bottom) {
            right--;
            direction = 2;
        } else if (direction == 2 && col == left) {
            bottom--;
            direction = 3;
        } else if (direction == 3 && row == top) {
            left++;
            direction = 0;
        }
        if (direction == 0) col++;
        else if (direction == 1) row++;
        else if (direction == 2) col--;
        else row--;
    }
    return 0;
}
