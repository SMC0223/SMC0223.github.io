// 입력: 양의 정수 n.
#include <stdio.h>

int main(void) {
    int n = 0;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
