#include <stdio.h>

int main(void) {
    int scores[4] = {80, 95, 70, 85};
    float temperatures[4] = {18.5f, 20.0f, 21.5f, 19.0f};
    double lengths[4] = {0.125, 1.234567, 2.5, 3.141592};
    char grades[4] = {'A', 'B', 'C', 'A'};

    for (int i = 0; i < 4; i++) {
        printf("%d ", scores[i]);
    }
    printf("\n");
    for (int i = 0; i < 4; i++) {
        printf("%.1f ", temperatures[i]);
    }
    printf("\n");
    for (int i = 0; i < 4; i++) {
        printf("%.6f ", lengths[i]);
    }
    printf("\n");
    for (int i = 0; i < 4; i++) {
        printf("%c ", grades[i]);
    }
    printf("\n");
    return 0;
}
